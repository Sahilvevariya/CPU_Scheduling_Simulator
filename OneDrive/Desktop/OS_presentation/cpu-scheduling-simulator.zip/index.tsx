/* tslint:disable */
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

// This tells TypeScript that 'd3' is a global variable provided by the D3.js script.
declare var d3: any;

// FIX: Renamed `Process` to `CPUProcess` to avoid name collision with Node.js's global `Process` type.
interface CPUProcess {
    id: number;
    name: string;
    arrivalTime: number;
    burstTime: number;
    priority: number;
    color: string;
    completionTime?: number;
    turnaroundTime?: number;
    waitingTime?: number;
}

interface Metrics {
    avgWaitingTime: number;
    avgTurnaroundTime: number;
}

class CPUSimulator {
    // FIX: Updated type from `Process[]` to `CPUProcess[]`.
    private processes: CPUProcess[] = [];
    private activeSection: string = 'intro';
    private comparisonResults: { [key: string]: Metrics } = {};

    constructor() {
        this.initializeProcesses();
        this.bindDOMEvents();
        this.render();
    }

    private initializeProcesses() {
        this.processes = [
            { id: 1, name: 'P1', arrivalTime: 0, burstTime: 8, priority: 3, color: '#3b82f6' },
            { id: 2, name: 'P2', arrivalTime: 1, burstTime: 4, priority: 1, color: '#22c55e' },
            { id: 3, name: 'P3', arrivalTime: 2, burstTime: 9, priority: 4, color: '#f97316' },
            { id: 4, name: 'P4', arrivalTime: 3, burstTime: 5, priority: 2, color: '#a855f7' },
        ];
    }

    private bindDOMEvents() {
        document.querySelector('#nav-links').addEventListener('click', (e) => {
            const target = e.target as HTMLAnchorElement;
            if (target.matches('a.nav-link')) {
                e.preventDefault();
                this.activeSection = target.getAttribute('href').substring(1);
                this.updateNavLinks();
                this.render();
            }
        });

        document.getElementById('run-fcfs').addEventListener('click', () => this.runSimulation('fcfs'));
        document.getElementById('run-sjf').addEventListener('click', () => this.runSimulation('sjf'));
        document.getElementById('run-priority').addEventListener('click', () => this.runSimulation('priority'));
        document.getElementById('quiz-form').addEventListener('submit', (e) => this.submitQuiz(e));
    }

    private updateNavLinks() {
        document.querySelectorAll('a.nav-link').forEach(link => {
            link.classList.remove('text-blue-600', 'dark:text-blue-400', 'border-b-2', 'border-blue-600', 'dark:border-blue-400', 'font-semibold');
            link.classList.add('text-gray-600', 'dark:text-gray-400', 'font-medium');
            if (link.getAttribute('href') === `#${this.activeSection}`) {
                link.classList.add('text-blue-600', 'dark:text-blue-400', 'border-b-2', 'border-blue-600', 'dark:border-blue-400', 'font-semibold');
                link.classList.remove('text-gray-600', 'dark:text-gray-400', 'font-medium');
            }
        });
    }

    private runSimulation(algorithm: 'fcfs' | 'sjf' | 'priority') {
        // Update processes from inputs if available
        if (algorithm === 'sjf' || algorithm === 'priority') {
            this.updateProcessesFromTable(algorithm);
        }

        // FIX: Updated type from `Process[]` to `CPUProcess[]`.
        let scheduledProcesses: CPUProcess[];
        let metrics: Metrics;

        switch (algorithm) {
            case 'fcfs':
                ({ scheduledProcesses, metrics } = this.calculateFCFS());
                break;
            case 'sjf':
                ({ scheduledProcesses, metrics } = this.calculateSJF());
                break;
            case 'priority':
                ({ scheduledProcesses, metrics } = this.calculatePriority());
                break;
        }

        this.comparisonResults[algorithm] = metrics;
        const resultsEl = document.getElementById(`${algorithm}-results`);
        resultsEl.classList.remove('hidden');
        this.renderGanttChart(scheduledProcesses, `#${algorithm}-gantt-chart`);
        this.renderMetrics(metrics, `#${algorithm}-metrics`);
        this.renderComparisonTable();
    }

    // FIX: Updated return type from `Process[]` to `CPUProcess[]`.
    private calculateFCFS(): { scheduledProcesses: CPUProcess[], metrics: Metrics } {
        const processes = [...this.processes].sort((a, b) => a.arrivalTime - b.arrivalTime);
        return this.executeSchedule(processes);
    }
    
    // FIX: Updated return type from `Process[]` to `CPUProcess[]`.
    private calculateSJF(): { scheduledProcesses: CPUProcess[], metrics: Metrics } {
        const processes = [...this.processes].sort((a, b) => a.burstTime - b.burstTime);
        return this.executeSchedule(processes);
    }
    
    // FIX: Updated return type from `Process[]` to `CPUProcess[]`.
    private calculatePriority(): { scheduledProcesses: CPUProcess[], metrics: Metrics } {
        const processes = [...this.processes].sort((a, b) => a.priority - b.priority);
        return this.executeSchedule(processes);
    }

    // FIX: Updated parameter and return types from `Process[]` to `CPUProcess[]`.
    private executeSchedule(processQueue: CPUProcess[]): { scheduledProcesses: CPUProcess[], metrics: Metrics } {
        let currentTime = 0;
        let totalWaitingTime = 0;
        let totalTurnaroundTime = 0;
        const scheduledProcesses = [];

        for (const process of processQueue) {
            if (currentTime < process.arrivalTime) {
                currentTime = process.arrivalTime;
            }

            process.waitingTime = currentTime - process.arrivalTime;
            process.completionTime = currentTime + process.burstTime;
            process.turnaroundTime = process.completionTime - process.arrivalTime;
            
            totalWaitingTime += process.waitingTime;
            totalTurnaroundTime += process.turnaroundTime;

            scheduledProcesses.push({
                ...process,
                startTime: currentTime
            });

            currentTime = process.completionTime;
        }

        const metrics: Metrics = {
            avgWaitingTime: totalWaitingTime / processQueue.length,
            avgTurnaroundTime: totalTurnaroundTime / processQueue.length
        };

        return { scheduledProcesses, metrics };
    }

    private render() {
        document.querySelectorAll('.app-section').forEach(section => {
            section.classList.add('hidden');
        });
        document.getElementById(this.activeSection).classList.remove('hidden');

        this.renderProcessTable('#intro-process-table', false);
        this.renderProcessTable('#sjf-process-table', true, 'burstTime');
        this.renderProcessTable('#priority-process-table', true, 'priority');
        this.renderComparisonTable();
    }
    
    private renderProcessTable(containerId: string, isEditable: boolean, editableField?: 'burstTime' | 'priority') {
        const container = document.querySelector(containerId);
        const table = `
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-200 dark:bg-gray-700">
                        <th class="p-3 font-semibold">Process</th>
                        <th class="p-3 font-semibold">Arrival Time</th>
                        <th class="p-3 font-semibold">Burst Time</th>
                        <th class="p-3 font-semibold">Priority</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.processes.map(p => `
                        <tr class="border-b border-gray-200 dark:border-gray-700">
                            <td class="p-3 flex items-center"><span class="w-4 h-4 rounded-full mr-3" style="background-color: ${p.color}"></span>${p.name}</td>
                            <td class="p-3">${p.arrivalTime}</td>
                            <td class="p-3">
                                ${isEditable && editableField === 'burstTime'
                                    ? `<input type="number" class="w-20 p-1 bg-gray-50 dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded" data-pid="${p.id}" data-field="burstTime" value="${p.burstTime}" min="1">`
                                    : p.burstTime
                                }
                            </td>
                            <td class="p-3">
                                ${isEditable && editableField === 'priority'
                                    ? `<input type="number" class="w-20 p-1 bg-gray-50 dark:bg-gray-600 border border-gray-300 dark:border-gray-500 rounded" data-pid="${p.id}" data-field="priority" value="${p.priority}" min="1">`
                                    : p.priority
                                }
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        container.innerHTML = table;
    }

    private updateProcessesFromTable(algorithm: 'sjf' | 'priority') {
        const field = algorithm === 'sjf' ? 'burstTime' : 'priority';
        document.querySelectorAll(`#${algorithm}-process-table input[data-field="${field}"]`).forEach(inputEl => {
            const input = inputEl as HTMLInputElement;
            const pid = parseInt(input.dataset.pid);
            const value = parseInt(input.value);
            const process = this.processes.find(p => p.id === pid);
            if (process && !isNaN(value) && value > 0) {
                process[field] = value;
            }
        });
    }

    private renderGanttChart(data: any[], containerId: string) {
        const container = d3.select(containerId);
        container.selectAll('*').remove(); // Clear previous chart

        const margin = { top: 20, right: 30, bottom: 40, left: 40 };
        const width = (container.node() as HTMLElement).getBoundingClientRect().width - margin.left - margin.right;
        const height = 150 - margin.top - margin.bottom;

        const svg = container.append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append('g')
            .attr('transform', `translate(${margin.left}, ${margin.top})`);

        const maxTime = d3.max(data, (d: any) => d.completionTime);

        const xScale = d3.scaleLinear()
            .domain([0, maxTime])
            .range([0, width]);

        svg.append('g')
            .attr('transform', `translate(0, ${height})`)
            .call(d3.axisBottom(xScale).ticks(Math.min(10, maxTime)));

        const barHeight = 40;
        svg.selectAll('rect')
            .data(data)
            .enter()
            .append('rect')
            .attr('x', d => xScale(d.startTime))
            .attr('y', height / 2 - barHeight / 2)
            .attr('width', d => xScale(d.burstTime))
            .attr('height', barHeight)
            .attr('fill', d => d.color)
            .attr('stroke', '#333')
            .attr('stroke-width', 1);

        svg.selectAll('text.process-label')
            .data(data)
            .enter()
            .append('text')
            .attr('class', 'process-label')
            .attr('x', d => xScale(d.startTime) + xScale(d.burstTime) / 2)
            .attr('y', height / 2 + 5)
            .attr('text-anchor', 'middle')
            .attr('fill', 'white')
            .style('font-weight', 'bold')
            .text(d => d.name);
    }
    
    private renderMetrics(metrics: Metrics, containerId: string) {
        const container = document.querySelector(containerId);
        container.innerHTML = `
            <div class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                <h4 class="font-semibold text-lg">Avg. Waiting Time</h4>
                <p class="text-2xl font-bold text-blue-500">${metrics.avgWaitingTime.toFixed(2)}</p>
            </div>
            <div class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                <h4 class="font-semibold text-lg">Avg. Turnaround Time</h4>
                <p class="text-2xl font-bold text-green-500">${metrics.avgTurnaroundTime.toFixed(2)}</p>
            </div>
        `;
    }

    private renderComparisonTable() {
        const container = document.getElementById('comparison-table');
        const algorithms = ['fcfs', 'sjf', 'priority'];
        const table = `
             <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-200 dark:bg-gray-700">
                        <th class="p-3 font-semibold">Algorithm</th>
                        <th class="p-3 font-semibold">Avg. Waiting Time</th>
                        <th class="p-3 font-semibold">Avg. Turnaround Time</th>
                    </tr>
                </thead>
                <tbody>
                    ${algorithms.map(alg => `
                        <tr class="border-b border-gray-200 dark:border-gray-700">
                            <td class="p-3 font-bold">${alg.toUpperCase()}</td>
                            <td class="p-3">${this.comparisonResults[alg] ? this.comparisonResults[alg].avgWaitingTime.toFixed(2) : 'N/A'}</td>
                            <td class="p-3">${this.comparisonResults[alg] ? this.comparisonResults[alg].avgTurnaroundTime.toFixed(2) : 'N/A'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
        container.innerHTML = table;
    }

    private submitQuiz(e: Event) {
        e.preventDefault();
        const form = e.target as HTMLFormElement;
        const formData = new FormData(form);
        const answers = {
            q1: formData.get('q1'),
            q2: formData.get('q2'),
        };
        const correctAnswers = { q1: 'fcfs', q2: 'sjf' };
        let score = 0;
        if (answers.q1 === correctAnswers.q1) score++;
        if (answers.q2 === correctAnswers.q2) score++;

        const resultsEl = document.getElementById('quiz-results');
        resultsEl.innerHTML = `
            <p class="text-lg font-semibold">You scored ${score} out of 2!</p>
            <div class="mt-2 space-y-1">
                <p>1. Convoy effect: <strong>FCFS</strong> ${answers.q1 === correctAnswers.q1 ? '✅' : '❌'}</p>
                <p>2. Minimum average waiting time: <strong>SJF</strong> ${answers.q2 === correctAnswers.q2 ? '✅' : '❌'}</p>
            </div>
        `;
    }
}

// Initialize the simulator once the DOM is ready
window.addEventListener('DOMContentLoaded', () => {
    new CPUSimulator();
});
